"use client"

import { motion } from "framer-motion"
import { Brain, Lightbulb, Rocket } from "lucide-react"

export default function VisionSection() {
  return (
    <section id="vision" className="py-20 bg-black/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">My Dream</span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-black/60 backdrop-blur-lg border border-purple-500/20 rounded-3xl p-8 overflow-hidden">
                <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"></div>
                <div className="relative z-10">
                  <div className="flex justify-center mb-8">
                    <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl">
                      <Brain className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-center mb-6">Pursuing AI/ML Excellence</h3>
                  <p className="text-gray-300 text-center">
                    My dream is to become an expert in Artificial Intelligence and Machine Learning, creating innovative
                    solutions that can positively impact people's lives. I envision developing AI systems that can solve
                    complex problems, enhance human capabilities, and contribute to technological advancement.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="flex items-start gap-6">
              <div className="bg-blue-500/20 p-3 rounded-lg mt-1">
                <Lightbulb className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Innovative Research</h3>
                <p className="text-gray-300">
                  I aspire to contribute to cutting-edge research in AI and ML, exploring new algorithms, techniques,
                  and applications that can push the boundaries of what's possible.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-6">
              <div className="bg-purple-500/20 p-3 rounded-lg mt-1">
                <Rocket className="h-6 w-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Practical Applications</h3>
                <p className="text-gray-300">
                  I want to develop AI applications that solve real-world problems, from healthcare diagnostics to
                  environmental monitoring, creating technology that makes a meaningful difference.
                </p>
              </div>
            </div>

            <div className="mt-10 p-6 bg-black/40 backdrop-blur-lg border border-purple-500/20 rounded-xl">
              <blockquote className="text-gray-300 italic">
                "My journey in technology is just beginning, but I'm driven by a vision of creating intelligent systems
                that augment human potential and address global challenges. Through continuous learning and innovation,
                I hope to contribute to a future where AI empowers everyone."
              </blockquote>
              <p className="text-right mt-4 text-purple-400 font-semibold">— Alok Sharma</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
