"use client"

import { motion } from "framer-motion"
import { User, Code, Palette } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutSection() {
  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">About Me</span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="bg-black/40 backdrop-blur-lg border border-purple-500/20 shadow-lg shadow-purple-500/10 overflow-hidden">
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-blue-500/20 p-3 rounded-lg">
                      <User className="h-6 w-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">BSc.CSIT Student</h3>
                      <p className="text-gray-300">
                        Currently in my 2nd semester, I'm passionate about computer science and information technology,
                        exploring the vast world of tech with curiosity and dedication.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-purple-500/20 p-3 rounded-lg">
                      <Code className="h-6 w-6 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Python Enthusiast</h3>
                      <p className="text-gray-300">
                        I'm currently learning Python programming, fascinated by its versatility and power in data
                        science, AI, and web development.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-blue-500/20 p-3 rounded-lg">
                      <Palette className="h-6 w-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Design Explorer</h3>
                      <p className="text-gray-300">
                        Alongside coding, I'm developing my skills in Photoshop, combining technical knowledge with
                        creative design to build visually appealing solutions.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-bold mb-4">My Journey</h3>
            <p className="text-gray-300 mb-4">
              As a BSc.CSIT student, I'm at the beginning of an exciting journey into the world of technology. My
              passion for problem-solving and innovation drives me to explore various aspects of computer science.
            </p>
            <p className="text-gray-300 mb-4">
              I'm particularly drawn to the fields of Artificial Intelligence and Machine Learning, which I believe will
              shape our future in profound ways. Learning Python is my first step toward mastering these domains.
            </p>
            <p className="text-gray-300">
              Beyond coding, I'm developing my creative skills through Photoshop, understanding that great technology
              should not only function well but also look appealing. This combination of technical and design skills is
              what I believe will set me apart in my future career.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
