"use client"

import { motion } from "framer-motion"
import { Code2, Lightbulb, BookOpen, PenTool } from "lucide-react"

const skills = [
  {
    name: "Python Programming",
    level: "Beginner",
    icon: <Code2 className="h-6 w-6" />,
    color: "from-blue-500 to-blue-700",
    percentage: 40,
  },
  {
    name: "Photoshop Design",
    level: "Beginner",
    icon: <PenTool className="h-6 w-6" />,
    color: "from-purple-500 to-purple-700",
    percentage: 35,
  },
  {
    name: "AI/ML Concepts",
    level: "Learning",
    icon: <Lightbulb className="h-6 w-6" />,
    color: "from-blue-400 to-purple-600",
    percentage: 25,
  },
  {
    name: "Academic Knowledge",
    level: "Intermediate",
    icon: <BookOpen className="h-6 w-6" />,
    color: "from-purple-400 to-blue-600",
    percentage: 65,
  },
]

export default function SkillsSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.8 },
    },
  }

  return (
    <section id="skills" className="py-20 bg-black/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              My Skills
            </span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto"></div>
          <p className="text-gray-300 mt-6 max-w-2xl mx-auto">
            As a student in the early stages of my tech journey, I'm actively developing these skills to build a strong
            foundation for my future career.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8"
        >
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-black/40 backdrop-blur-lg border border-purple-500/20 rounded-xl p-6 hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className={`bg-gradient-to-r ${skill.color} p-3 rounded-lg text-white`}>{skill.icon}</div>
                <div>
                  <h3 className="text-xl font-semibold">{skill.name}</h3>
                  <p className="text-gray-400">{skill.level}</p>
                </div>
              </div>
              <div className="h-2 w-full bg-gray-800 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${skill.color} rounded-full`}
                  style={{ width: `${skill.percentage}%` }}
                ></div>
              </div>
              <div className="mt-2 text-right text-gray-400 text-sm">{skill.percentage}%</div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <h3 className="text-2xl font-semibold mb-4">Learning Path</h3>
          <div className="max-w-3xl mx-auto bg-black/40 backdrop-blur-lg border border-purple-500/20 rounded-xl p-6">
            <div className="relative">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full"></div>
              <div className="space-y-8 pl-8">
                <div>
                  <div className="absolute left-0 w-4 h-4 rounded-full bg-blue-500 -ml-1.5"></div>
                  <h4 className="text-xl font-semibold text-blue-400">Python Fundamentals</h4>
                  <p className="text-gray-300 mt-2">
                    Currently mastering the basics of Python programming, including data structures, functions, and
                    object-oriented programming concepts.
                  </p>
                </div>
                <div>
                  <div className="absolute left-0 w-4 h-4 rounded-full bg-purple-500 -ml-1.5"></div>
                  <h4 className="text-xl font-semibold text-purple-400">Design Skills</h4>
                  <p className="text-gray-300 mt-2">
                    Learning Photoshop techniques to create visually appealing designs and user interfaces.
                  </p>
                </div>
                <div>
                  <div className="absolute left-0 w-4 h-4 rounded-full bg-blue-400 -ml-1.5"></div>
                  <h4 className="text-xl font-semibold text-blue-400">AI/ML Foundations</h4>
                  <p className="text-gray-300 mt-2">
                    Beginning to explore the theoretical concepts behind Artificial Intelligence and Machine Learning.
                  </p>
                </div>
                <div>
                  <div className="absolute left-0 w-4 h-4 rounded-full bg-purple-400 -ml-1.5"></div>
                  <h4 className="text-xl font-semibold text-purple-400">Future Goals</h4>
                  <p className="text-gray-300 mt-2">
                    Planning to dive into data science libraries, advanced AI concepts, and full-stack development.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
