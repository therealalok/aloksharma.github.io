"use client"

import { motion } from "framer-motion"
import { ExternalLink, Github, Code } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const projects = [
  {
    title: "AI Image Generator",
    description:
      "Future project to create an AI-powered image generation tool using Python and machine learning libraries.",
    tags: ["Python", "AI", "ML", "Image Processing"],
    icon: <Code className="h-6 w-6" />,
    color: "from-blue-500 to-purple-500",
  },
  {
    title: "Data Visualization Dashboard",
    description: "Upcoming project to build an interactive dashboard for visualizing complex datasets.",
    tags: ["Python", "Data Science", "Web Development"],
    icon: <Code className="h-6 w-6" />,
    color: "from-purple-500 to-blue-500",
  },
  {
    title: "Creative Portfolio Designs",
    description: "Collection of Photoshop designs showcasing creative portfolio layouts and UI elements.",
    tags: ["Photoshop", "UI/UX", "Design"],
    icon: <Code className="h-6 w-6" />,
    color: "from-blue-400 to-purple-600",
  },
  {
    title: "Academic Research Paper",
    description: "Research on emerging technologies in computer science and their potential applications.",
    tags: ["Research", "Academic", "Technology"],
    icon: <Code className="h-6 w-6" />,
    color: "from-purple-400 to-blue-600",
  },
]

export default function ProjectsSection() {
  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Future Projects
            </span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto"></div>
          <p className="text-gray-300 mt-6 max-w-2xl mx-auto">
            These are the projects I'm planning to work on as I continue to develop my skills in programming and design.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full bg-black/40 backdrop-blur-lg border border-purple-500/20 overflow-hidden group hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-300">
                <CardContent className="p-0">
                  <div className={`h-2 w-full bg-gradient-to-r ${project.color}`}></div>
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-xl font-bold">{project.title}</h3>
                      <div className={`p-2 rounded-full bg-gradient-to-r ${project.color} text-white`}>
                        {project.icon}
                      </div>
                    </div>
                    <p className="text-gray-300 mb-6">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {project.tags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="text-xs px-3 py-1 rounded-full bg-purple-900/30 text-purple-300"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-3 mt-auto">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
                        disabled
                      >
                        <Github className="h-4 w-4 mr-2" />
                        Coming Soon
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-blue-500/50 text-blue-300 hover:bg-blue-500/20"
                        disabled
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <p className="text-gray-300 italic">
            "These projects represent my aspirations as I continue to learn and grow in the field of technology."
          </p>
        </motion.div>
      </div>
    </section>
  )
}
