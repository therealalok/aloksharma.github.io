import type { Metadata } from "next"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import AboutSection from "@/components/about-section"
import SkillsSection from "@/components/skills-section"
import ProjectsSection from "@/components/projects-section"
import VisionSection from "@/components/vision-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import ParticleBackground from "@/components/particle-background"

export const metadata: Metadata = {
  title: "Alok Sharma | Future AI/ML Innovator",
  description: "Portfolio of Alok Sharma, BSc.CSIT student and future AI/ML innovator",
}

export default function Home() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-black via-purple-950 to-blue-950 text-white overflow-hidden">
      <ParticleBackground />
      <div className="relative z-10">
        <Navbar />
        <main>
          <HeroSection />
          <AboutSection />
          <SkillsSection />
          <ProjectsSection />
          <VisionSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </div>
  )
}
